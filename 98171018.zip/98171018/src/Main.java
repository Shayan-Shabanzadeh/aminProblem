import view.MainMenu;

public class Main {
    public static void main(String[] args){
        MainMenu mainMenu = new MainMenu();
        mainMenu.show();
        mainMenu.execute();

    }
}
